//
//  UserModel.swift
//  VolleyBallStatistic(SwiftUI)
//
//  Created by Roman Yarmoliuk on 29.03.2023.
//

import SwiftUI

    
struct Player: Identifiable, Codable {
    let id: UUID
    var firstName: String
    var lastName: String
    var profilePicture: Data?
}

class CreateUserViewModel: ObservableObject {
    
    @Published var player: Player
    
    init() {
        player = Player(id: UUID(), firstName: "", lastName: "")
    }
    
    init(player: Player) {
        self.player = player
    }
    
    func savePlayer(_ player: Player) {
        UserDefaultsManager.shared.addPlayer(player)
    }
}

struct Team: Identifiable, Codable {
    let id: UUID
    var name: String = "Team 1"
    var players: [Player]
}


var events = [GameEvent]()

struct GameEvent {
    var type: EventType
    var team: String
    var player: UUID
    var time: Double
}

enum EventType {
    case attack, block, ace
    case doble, line, serve, net, technical, other // mistakes
}
