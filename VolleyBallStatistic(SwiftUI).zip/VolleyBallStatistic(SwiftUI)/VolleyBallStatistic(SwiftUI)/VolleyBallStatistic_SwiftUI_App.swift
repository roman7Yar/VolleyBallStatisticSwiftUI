//
//  VolleyBallStatistic_SwiftUI_App.swift
//  VolleyBallStatistic(SwiftUI)
//
//  Created by Roman Yarmoliuk on 28.03.2023.
//

import SwiftUI

@main
struct VolleyBallStatistic_SwiftUI_App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
